package com.example.foryoudicodingkadesubtwo.ImageAway

import com.example.foryoudicodingkadesubtwo.view.model.ImageAwayInit

data class ImageAwayResponse (
    val teams: List<ImageAwayInit>
)