package com.example.foryoudicodingkadesubtwo.view.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class ImageHomeInit(
    val strTeamBadge: String?
) : Parcelable