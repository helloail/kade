package com.example.foryoudicodingkadesubtwo.Search

import com.example.foryoudicodingkadesubtwo.view.model.NextMatchInit
import com.example.foryoudicodingkadesubtwo.view.model.SearchActivityInit

data class SearchMatchResponse (
    val event: List<SearchActivityInit>
)