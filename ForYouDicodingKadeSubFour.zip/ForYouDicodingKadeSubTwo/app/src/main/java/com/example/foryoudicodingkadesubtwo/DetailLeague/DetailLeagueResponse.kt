package com.example.foryoudicodingkadesubtwo.DetailLeague

import com.example.foryoudicodingkadesubtwo.view.model.DetailLeagueInit

data class DetailLeagueResponse (
    val leagues: List<DetailLeagueInit>)