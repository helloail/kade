package com.example.foryoudicodingkadesubtwo.NextMatch

import com.example.foryoudicodingkadesubtwo.view.model.NextMatchInit

data class NextMatchRespoonse(
    val events: List<NextMatchInit>)