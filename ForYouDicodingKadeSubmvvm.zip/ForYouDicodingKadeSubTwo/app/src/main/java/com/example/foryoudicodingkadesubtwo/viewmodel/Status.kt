package com.example.foryoudicodingkadesubtwo.viewmodel

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}