package com.example.foryoudicodingkadesubtwo.PastMatch

import com.example.foryoudicodingkadesubtwo.ApiRepository
import com.example.foryoudicodingkadesubtwo.CoroutineContextProvider
import com.example.foryoudicodingkadesubtwo.DBApi
import com.example.foryoudicodingkadesubtwo.NextMatch.NextMatchRespoonse
import com.example.foryoudicodingkadesubtwo.NextMatch.NextView
import com.google.gson.Gson
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class PastMatchPresenter (private val view: PastMatchView,
                          private val apiRepository: ApiRepository,
                          private val gson: Gson, private val contextPool: CoroutineContextProvider = CoroutineContextProvider()
) {

    fun getPastMatchList(teamId: String?) {
        view.showLoading()

        GlobalScope.launch(contextPool.main){
            val data = gson.fromJson(apiRepository
                .doRequestAsync(DBApi.getPastMatch(teamId)).await(),
                PastMatchResponse::class.java
            )
            view.showTeamList(data.events)
            view.hideLoading()
        }
    }

}