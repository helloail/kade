package com.example.foryoudicodingkadesubtwo.ImageHome

import com.example.foryoudicodingkadesubtwo.view.model.ImageHomeInit
import com.example.foryoudicodingkadesubtwo.view.model.PastMatchInit

data class ImageHomeResponse (
    val teams: List<ImageHomeInit>
)