package com.example.foryoudicodingkadesubtwo.PastMatch

import com.example.foryoudicodingkadesubtwo.view.model.PastMatchInit

data class PastMatchResponse(
    val events: List<PastMatchInit>
)
