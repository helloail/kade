package com.example.foryoudicodingkadesubtwo.Test


import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.example.foryoudicodingkadesubtwo.Resource
import com.example.foryoudicodingkadesubtwo.mock
import com.example.foryoudicodingkadesubtwo.view.model.DetailLeagueInit
import com.example.foryoudicodingkadesubtwo.viewmodel.DetailLeagueViewModel
import com.jraska.livedata.test
import com.nhaarman.mockitokotlin2.argumentCaptor
import com.nhaarman.mockitokotlin2.eq
import kotlinx.coroutines.Dispatchers
import org.junit.Assert
import org.junit.Assert.assertEquals

import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.ArgumentCaptor
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.mockito.MockitoAnnotations

class DetailMatchTest {

    @get:Rule
    val rule = InstantTaskExecutorRule()

    @Mock
    private lateinit var detailLeagueViewModel: DetailLeagueViewModel

    private val mainRepository = Mockito.mock(DetailLeagueViewModel::class.java)


    private val observer: Observer<List<DetailLeagueInit>> = mock()



    val id = "4337"


    @Before
    fun before() {

        MockitoAnnotations.initMocks(this)
        detailLeagueViewModel = DetailLeagueViewModel()

    }

    @Test
    fun getLeagueDetailSuccsess() {

        val dummy = Resource.success(listOf<DetailLeagueInit>())
        val observer = MutableLiveData<Resource<List<DetailLeagueInit>>>()
        observer.value = dummy

        Mockito.`when`(mainRepository.getListMovie()).thenReturn(observer)


        val expectedUser = DetailLeagueInit(
            "Dutch Eredivisie",
            "Male",
            "Holland",
            "https://www.thesportsdb.com/images/media/league/badge/ywoi5k1534590331.png"
        )


        mainRepository.getListMovie()
        argumentCaptor<List<DetailLeagueInit>>().apply {

            verify(detailLeagueViewModel).setListmovie(eq(id))
        }


//        detailLeagueViewModel.setListmovie(id)
//
//       val captor = ArgumentCaptor.forClass(DetailLeagueInit::class.java)
//        captor.run {
//            verify(observer, times(1)).onChanged(listOf(capture()))
//            assertEquals(expectedUser, value)
//        }

    }
}
